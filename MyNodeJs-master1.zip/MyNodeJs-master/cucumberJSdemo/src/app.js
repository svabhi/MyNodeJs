module.exports = {
  isItFriday: function(today) {
    if (today === "Friday") {
      return "TGIF";
    } else {
      return "Nope";
    }
  },
  isItMonday: function(today) {
    if (today === "Monday") {
      return "TGIM";
    } else {
      return "Nope";
    }
  }
};
