# CucumberJS demonstration

Code for a brief and simple demo using CucumberJS within a Node project done for bonus marks for college classes.

Tutorial from: https://cucumber.io/docs/guides/10-minute-tutorial/

YouTube video accompanying demo: https://www.youtube.com/watch?v=x4jP9ksCnMY
